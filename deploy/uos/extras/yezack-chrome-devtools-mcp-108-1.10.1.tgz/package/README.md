# @yezack/chrome-devtools-mcp-108

Unofficial fork of [chrome-devtools-mcp](https://github.com/ChromeDevTools/chrome-devtools-mcp)
that also works against **Chrome/Chromium 108-110**.

The upstream package requires Chrome 111+ for page discovery: on Chrome 108 the
connection-level `Target.setAutoAttach` filter suppresses every target, so
`list_pages` returns an empty array. This fork removes that filter on browsers
older than 111 and is otherwise identical to upstream 1.10.1. See
[FORK-NOTICE.md](./FORK-NOTICE.md) for the exact change and the evidence.

## Usage

    npx @yezack/chrome-devtools-mcp-108 --browserUrl http://127.0.0.1:9222

Or let it start Chrome 108 itself (note `--headless=shell`: puppeteer would
otherwise pass `--headless=new`, which Chrome 108 does not understand):

    npx @yezack/chrome-devtools-mcp-108 \
      --executablePath "C:/path/to/chrome108/chrome.exe" \
      --headless=shell --user-data-dir "C:/path/to/profile" \
      --chrome-arg=--no-sandbox

MCP client configuration:

    {
      "mcpServers": {
        "chrome-devtools": {
          "command": "npx",
          "args": ["-y", "@yezack/chrome-devtools-mcp-108",
                   "--browserUrl", "http://127.0.0.1:9222",
                   "--no-usage-statistics"]
        }
      }
    }

## Bins

`chrome-devtools-mcp-108` and `chrome-devtools-108` (renamed so they cannot
collide with the official package's bins).

## Not Google

This is not an official Google package. Use
[`chrome-devtools-mcp`](https://www.npmjs.com/package/chrome-devtools-mcp) if
you are on Chrome 111+.
