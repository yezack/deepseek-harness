/**
 * 反向代理路径前缀解析与安全重定向工具
 */
/**
 * 校验并提取反向代理传递的前缀路径 (如 X-Forwarded-Prefix)
 *
 * 安全约束：
 * 1. 必须以单个 / 开头，且不能以 // 开头（防御协议相对 URL 与开放重定向）
 * 2. 不能包含协议标识 (http:, https:, etc.)
 * 3. 不能包含反斜杠或控制字符（防御浏览器 URL 规范化逃逸与 CRLF 注入）
 * 4. 去除末尾冗余的斜杠
 */
export declare function resolveForwardedPrefix(raw: unknown): string;
/**
 * 构造带网关前缀的重定向目标路径
 * @param headers 请求头
 * @param targetPath 目标相对路径，如 '/auth' 或 '/'
 */
export declare function resolveRedirectPath(headers: Record<string, string | string[] | undefined> | undefined, targetPath: string): string;
