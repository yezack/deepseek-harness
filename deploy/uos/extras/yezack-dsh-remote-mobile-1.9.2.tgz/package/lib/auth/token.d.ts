import { EventEmitter } from 'node:events';
import type { IncomingMessage } from 'node:http';
export declare const AUTH_COOKIE_NAME = "dsh_mobile_token";
/** DSH_HOME 目录（支持 DSH_HOME 覆盖） */
export declare const DSH_HOME: string;
/** 插件自有数据目录 */
export declare const REMOTE_MOBILE_DIR: string;
export declare const DEFAULT_PERSIST_FILE: string;
/** 插件自有配置持久化文件（DSH 0.1.7+ 起官方弃用 settings.yaml，插件改为自持存储） */
export declare const SETTINGS_FILE: string;
/** DSH 旧版全局设置文件（0.1.7+ 起仅作一次性迁移来源，启动时会被改名） */
export declare const GLOBAL_SETTINGS_FILE: string;
/** DSH 迁移后遗留的旧设置存档（legacy settings.yaml → settings.yaml.imported） */
export declare const LEGACY_SETTINGS_IMPORTED_FILE: string;
/**
 * 从 ~/.dsh/settings.yaml 中安全读取 dsh-remote-mobile 命名空间的最新配置
 */
export declare function readFromSettingsYaml(filePath?: string): Partial<SessionStoreOptions>;
/**
 * 从旧版 settings.yaml 文本内容中解析 locale.preference（返回 null 表示未命中）
 */
export declare function parseLocaleFromSettingsYaml(content: string): 'zh' | 'en' | null;
/**
 * 从 cordis.patch.yml 文本内容中解析 locale entry 的 config.preference（返回 null 表示未命中）
 */
export declare function parseLocaleFromPatch(content: string): 'zh' | 'en' | null;
/**
 * 读取 DSH 全局语言偏好。
 *
 * DSH 0.1.7+ 起配置真实落点为当前 profile 的 cordis.patch.yml（旧版 settings.yaml
 * 已被一次性迁移并改名为 settings.yaml.imported），因此优先读取 profile patch，
 * 再回退旧 settings.yaml / settings.yaml.imported。
 *
 * @param filePath 显式传入时按旧版 settings.yaml 格式解析（向后兼容与测试）。
 */
export declare function readGlobalLocale(filePath?: string): 'zh' | 'en';
/**
 * 读取插件自有持久化配置文件 ~/.dsh/remote-mobile/settings.json
 *
 * 注：若文件中 secretHash 为空串 ""（表示用户清空了密码），此处会跳过赋值以归一化为 undefined。
 * 上层 resolveInitialStoreOptions 必须根据文件存在性（own !== null）做出决策，严禁在自有配置存在时用 legacy 兜底回退。
 */
export declare function readPluginSettingsJson(filePath?: string): Partial<SessionStoreOptions>;
/**
 * 将插件配置原子写回自有配置文件 ~/.dsh/remote-mobile/settings.json（权限 0600）。
 *
 * DSH 0.1.7+ 起官方已弃用 ~/.dsh/settings.yaml 作为实时配置源（启动时一次性迁移为
 * settings.yaml.imported），因此插件不再依赖该文件，改为自持存储，避免升级后配置丢失。
 */
export declare function writePluginSettingsJson(options: SessionStoreOptions, filePath?: string): boolean;
/**
 * 兼容读取 DSH 旧版 settings.yaml / 迁移后的 settings.yaml.imported 中的
 * dsh-remote-mobile 段，用于首次启动时把旧配置迁移到自有 settings.json。
 */
export declare function readLegacyDshSettings(liveFile?: string, importedFile?: string): Partial<SessionStoreOptions>;
/**
 * 解析 SessionStore 的初始运行配置（纯函数决策逻辑）。
 *
 * 优先级与防反噬规则：
 * 1. 显式传入的 explicit 参数优先级最高；
 * 2. 若自有配置文件已存在（own !== null），则以自有配置 own 为准，此时 legacy 配置被彻底忽略（防止已清空的密码死灰复燃）；
 * 3. 仅当自有配置文件尚不存在（own === null，即首次安装或旧版升级）时，才回退读取 legacy 配置进行一次性迁移；
 * 4. 最终缺失项采用系统安全默认值。
 *
 * @param explicit 构造函数传入的显式参数
 * @param own 插件自有 settings.json 内容；null 表示文件尚不存在（首次启动迁移状态）
 * @param legacy 旧版 settings.yaml / settings.yaml.imported 内容
 */
export declare function resolveInitialStoreOptions(explicit?: SessionStoreOptions, own?: Partial<SessionStoreOptions> | null, legacy?: Partial<SessionStoreOptions>): Required<SessionStoreOptions>;
export interface SessionRecord {
    token: string;
    createdAt: number;
    lastSeenAt: number;
    ip?: string;
    deviceName?: string;
    userAgent?: string;
    authType?: string;
    isBypass?: boolean;
}
export interface ShortCodeRecord {
    code: string;
    token: string;
    createdAt: number;
    expiresAt: number;
}
export interface IpSecurityStat {
    ip: string;
    authVisits: number;
    authVisitsInWindow: number;
    windowStart: number;
    failedAttempts: number;
    totalAttempts: number;
    lockedUntil: number;
    lastAttemptAt: number;
    lastSeenAt: number;
    authType?: string;
    deviceName?: string;
    userAgent?: string;
}
export interface SessionStoreOptions {
    allowTailscale?: boolean;
    allowLan?: boolean;
    secret?: string;
    secretHash?: string;
    devicesFile?: string;
    maxFailedAttempts?: number;
    lockDurationMs?: number;
    maxVisitsPerMinute?: number;
}
/**
 * 将 User-Agent 字符串解析为人类友好的设备名称
 */
export declare function parseDeviceName(ua?: string): string;
export declare class SessionStore extends EventEmitter {
    private sessions;
    private shortCodes;
    private ipStats;
    private options;
    private settingsMutator?;
    private debounceTimer;
    readonly persistPath: string;
    readonly settingsFilePath: string | null;
    constructor(options?: SessionStoreOptions);
    getOptions(): Required<SessionStoreOptions>;
    hasSecret(): boolean;
    setSettingsMutator(mutator: (patch: Partial<SessionStoreOptions>) => void): void;
    updateOptions(newOpts: Partial<SessionStoreOptions>, syncToSettings?: boolean): void;
    /**
     * 记录 IP 打开 /auth 页面的计数并进行限频判定与设备指纹解析
     */
    recordAuthVisit(ip: string, userAgent?: string): {
        allowed: boolean;
        lockedUntil?: number;
        reason?: string;
    };
    /**
     * 检查 IP 是否被防暴力破解锁定
     */
    isIpLocked(ip: string): {
        locked: boolean;
        lockedUntil?: number;
        remainingSeconds?: number;
    };
    /**
     * 获取所有 IP 的安全审计统计数据
     */
    getIpSecurityStats(): IpSecurityStat[];
    /**
     * 管理员手动解锁某个 IP
     */
    unlockIp(ip: string): boolean;
    generateShortCode(): {
        code: string;
        token: string;
        expiresAt: number;
    };
    verify(credential: string, userAgent?: string, clientIp?: string): {
        success: boolean;
        token?: string;
        reason?: string;
        locked?: boolean;
        remainingSeconds?: number;
    };
    private handleFailedAttempt;
    validateToken(token: string, clientIp?: string): boolean;
    extractTokenFromRequest(req: IncomingMessage): string | null;
    /**
     * 自动登记并归因免密直连设备（Tailscale / LAN）
     */
    registerBypassDevice(ip: string, userAgent: string | undefined, type: 'Tailscale' | 'LAN'): SessionRecord;
    getSessionsList(): {
        count: number;
        devices: Array<Omit<SessionRecord, 'userAgent'>>;
    };
    revokeDevice(token: string): boolean;
    revokeAllSessions(): void;
    /**
     * 清空所有 IP 安全审计与防暴破统计记录
     */
    clearAllIpSecurityStats(): void;
    loadPersistedData(): void;
    /**
     * 同步立即持久化落盘（由关键路径调用：配对成功、密码认证、撤销设备、手动改密/配置等）
     */
    savePersistedData(): void;
    /**
     * 500ms 防抖持久化落盘（由高频访问路径调用：每次打开 /auth、validateToken 重连时间戳更新等）
     */
    savePersistedDataDebounced(): void;
    /**
     * 立即执行待写的持久化数据落盘并清理定时器
     */
    flushPersistedData(): void;
}
