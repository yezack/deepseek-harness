# dsh-ga-controller

Enterprise private-agent lockdown layer for **DeepSeek Harness (DSH)**.

It turns a stock DSH install into an internal-only agent surface by removing the
DeepSeek cloud account/login capability, removing the built-in feedback
surfaces, and hiding the official brand chrome — without forking the host and
without touching `app.asar`.

> Feature point 1 of the enterprise plugin. Later points (SSO, model allow-list,
> DLP/session policy) plug into the same bundle as additional modules; see
> [docs/architecture.md](docs/architecture.md).

## What this build does

| Area | Mechanism | Effect |
|---|---|---|
| DeepSeek login / account UI | row `ui-settings-account` disabled | No Settings → Account & balance, no sidebar account launcher (the plain gear returns), no sign-in dialog, no Models sign-in step, no desktop onboarding overlay, no quota/bonus/sign-in notices |
| DeepSeek account model provider | row `llm-deepseek-account` disabled | No "DeepSeek 账号 / DeepSeek Account" card in Models, no account group in the model picker; the default model is re-pointed by the startup guard |
| Desktop / product telemetry | rows `product-analytics`, `desktop-product-telemetry` disabled | No account-injecting analytics; no product telemetry export (the shell's optional probe is `catch`-guarded) |
| Built-in feedback | rows `command-feedback`, `message-feedback`, `ui-message-feedback` disabled | No like/dislike strip, no `/feedback` command or dialog, no acknowledgement toasts, no session-header "反馈" item |
| Official brand row (`logoRow`) | browser CSS layer | Brand mark/name hidden and the whole row collapsed — no empty gap is left in the corner. Opt-in `keepTitlebarDragStrip` preserves the 40 px Windows drag strip. |
| Empty-session hero headline (`bq_headline`) | browser CSS layer | "Into the Unknown" / "探索未至之境" headline (whale + preview badge) hidden |
| Default-model guard | host half, startup | If the profile's default model no longer resolves after the account provider is removed (`NO_ADAPTER`), it is rewritten once to the first usable provider (or `fallbackModel`) through the normal config editor, so the host stays usable |

### Why the account service rows stay mounted

The **account RPC and platform service must stay enabled** on the desktop
profile. The Electron shell calls it before it opens its first window —
`app.asar/lib/main.js`: `openInitialWindow()` → `readWelcomeState()` → `read()`
→ `account.state()` → `POST /api/account/getState` (main.js:8964), and `read()`
has no fallback: a non-200 throws `desktop welcome: Web request failed`
(main.js:8903) into `reportFatal`, so **no window ever appears** even though the
host booted. Disabling `account-controller` / `deepseek-account` therefore breaks
the desktop app, not just the account UI.

What this build removes instead is the **renderer-side login/account surface**
(the whole `ui-settings-account` client plugin) plus the account **model
provider**. The account namespace stays alive for the shell; the login capability
is no longer reachable from the UI. Truly removing the capability needs an
Electron-shell patch (`main.js`), which a Cordis plugin cannot do. `verify.mjs`
fails the build if `account-controller` / `deepseek-account` are ever disabled
again.

Rows that **must stay mounted** and are deliberately untouched: `account-controller`,
`deepseek-account`, `credentials` (the web transport itself injects it — disabling
it kills the GUI), `settings-controller` (backs every Settings page) and
`authorization` (credential flows for enterprise providers).

## Not covered by a plugin (deployment prerequisites)

- **Desktop native welcome/sign-in window.** The Electron shell shows it when
  `!loggedIn && !hasApiKey`. It is not part of the Cordis row graph and cannot
  be removed by a plugin. Make sure at least one model API key is configured /
  discovered before first launch (see [docs/deploy.md](docs/deploy.md)).
- **Stored account grant + account RPC capability.** The shell requires the
  account namespace, so a stored grant remains resolvable by the host. Delete the
  account record from the credential store during provisioning if the seat must
  not retain one; for a capability-level block, patch the Electron shell.
- **Plugin management can re-enable rows.** An operator can toggle a disabled
  row back on from the Plugins page (it writes `disabled:` into the profile
  patch). Lock plugin management down separately for a locked-down seat.

## Default model: automatic guard, optional pin

Removing `llm-deepseek-account` removes the provider that the stock profile uses
as its default (`provider: deepseek-account`, `model: deepseek-flash`). Left
alone, every new session fails at its first request with
`NO_ADAPTER no adapter registered for provider "deepseek-account"` — the host
looks broken and the UI offers no repair path.

Two mechanisms cover it:

1. **Startup guard (default on, `repairDefaultModel: true`).** The host half
   classifies the configured default once providers settle. If the provider is
   gone or the model is no longer advertised, it rewrites `agent-default-model`
   to `fallbackModel` (when set) or the first provider that advertises a model,
   through the normal config editor, so the change persists. It never rewrites a
   default it cannot prove is broken (credential-gated/ambiguous catalog states
   are left alone).
2. **Install-time pin.** The installer can write the target explicitly and is
   the deterministic choice for fleet provisioning:

```powershell
node scripts/install-profile.mjs --profile desktop --default-model local-llm/qwen3.8-27b
```

It rewrites the profile's `agent-default-model` entry and drops the account-only
`reasoningEffort`. Set `repairDefaultModel: false` when a deployment pins its
default model out of band and must not have the plugin touch it.

## Install

```powershell
pnpm install
pnpm build
pnpm test
pnpm verify
```

Then install into the target profile (backups are automatic; the desktop profile
is installed by materializing the built package because the CLI reserves
`--profile desktop` for the Electron app):

```powershell
# guard repairs the default at first boot:
node scripts/install-profile.mjs --profile desktop
# or pin the target now:
node scripts/install-profile.mjs --profile desktop --default-model local-llm/qwen3.8-27b
```

Restart DeepSeek Harness (host composition is read at boot), then run the
verification checklist in [docs/deploy.md](docs/deploy.md). The full runbook —
preconditions, verification probes, rollback, upgrade procedure, known limits —
lives there.

## Configuration

The browser half reads its knobs from the plugin row in `cordis.patch.yml`.
Because the client module graph (`__DSH_BOOT__`) carries no config, the host half
publishes the resolved config through the webserver's index-injection table as
`window.__DSH_GA_CONFIG__` (a synchronous global set before any application
script runs); the browser half falls back to built-in defaults when the global is
absent. No RPC, no fetch, no flash of unstyled branding.

| Key | Default | Meaning |
|---|---|---|
| `hideLogoRow` | `true` | Hide the sidebar brand row and collapse it (no empty gap left behind) |
| `keepTitlebarDragStrip` | `false` | Keep the 40 px Windows drag strip instead of collapsing the row (only for shells that drag from it) |
| `hideHeroHeadline` | `true` | Hide the empty-session hero headline |
| `repairDefaultModel` | `true` | Rewrite an unroutable default model once so the host stays usable |
| `fallbackModel` | `''` | Preferred repair target (`provider/model`); empty = first provider with models |
| `extraSelectors` | `[]` | Extra CSS selectors to hide (deployment-specific leftovers) |

Disabling a whole feature row is a composition change, not a runtime knob: edit
the `disabled:` lines in `cordis.patch.yml` (and rebuild/reinstall) to restore an
official capability.

## Chrome 96 policy

Our own code is authored and built for **Chrome 96**: the browser bundle is
built with `target: 'chrome96'`, uses no `:has()`, no container queries, no
`color-mix()`, no `structuredClone`/`findLast`/`toSorted`/logical-assignment
syntax. `pnpm test` and `pnpm verify` fail the build if that regresses.

Important context: **the stock DSH 0.2.1 UI itself already requires a newer
Chromium** (it ships `:has()` CSS, `toSorted`, `findLast`, `structuredClone`), so
Chrome 96 cannot render the unmodified product. The policy here means "this
plugin adds no new floor"; raising the rest of the product to Chrome 96 would be
a separate compatibility workstream, not part of feature point 1.

## Repository layout

```
cordis.patch.yml        composition lockdown + plugin row
src/index.ts            host half: publishes the config global (index injection)
src/client/index.ts     browser half: installs the hide-layer stylesheet
src/shared/config.ts    config contract, defaults, global name
src/shared/css.ts       selector registry + stylesheet builder
test/client.test.mjs    integration tests against the built bundle
test/host.test.mjs      index-injection config publication test
scripts/verify.mjs      release-contract verifier (patch rows + Chrome 96 + artifacts)
scripts/install-profile.mjs
                        profile installer + default-model migration
docs/recon/             evidence-first host recon this design is based on
docs/deploy.md          deployment runbook, verification, rollback, limits
docs/architecture.md    mechanisms, upgrade strategy, extension points
docs/design-conversation-backup.md
                        DESIGN ONLY (implementation deferred): real-time,
                        plaintext conversation-log backup to a self-hosted
                        server (attachments off by default; no restore)
docs/design-backup-server-api.md
                        frozen P0 contract for the backup server:
                        FastAPI + PostgreSQL endpoints, DDL, tests
docs/api-backup-server.md
                        server-facing API reference (v1): HTTP + long-lived
                        WebSocket control channel, payloads, errors, limits
```

## License

MIT
