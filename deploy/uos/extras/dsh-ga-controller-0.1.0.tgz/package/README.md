# dsh-ga-controller (client)

Enterprise private-agent lockdown layer for **DeepSeek Harness (DSH)**.

This package is the `client/` side of the workspace (the DSH plugin). The
repository root also holds `server/` (placeholder) and shared `docs/`.

It turns a stock DSH install into an internal-only agent surface by removing the
DeepSeek cloud account/login capability, removing the built-in feedback
surfaces, and hiding the official brand chrome — without forking the host and
without touching `app.asar`.

> Feature point 1 of the enterprise plugin. Later points (SSO, model allow-list,
> DLP/session policy) plug into the same bundle as additional modules; see
> [../docs/architecture.md](../docs/architecture.md).

Commands below are run from the **repository root** (workspace scripts delegate
into `client/`), or prefix them with `cd client` and drop the `-C client`. 

## What this build does

| Area | Mechanism | Effect |
|---|---|---|
| DeepSeek login / account UI | row `ui-settings-account` disabled | No Settings → Account & balance, no sidebar account launcher (the plain gear returns), no sign-in dialog, no Models sign-in step, no desktop onboarding overlay, no quota/bonus/sign-in notices |
| DeepSeek account model provider | row `llm-deepseek-account` disabled | No "DeepSeek 账号 / DeepSeek Account" card in Models, no account group in the model picker; the default model is re-pointed by the startup guard |
| Desktop / product telemetry | rows `product-analytics`, `desktop-product-telemetry` disabled | No account-injecting analytics; no product telemetry export (the shell's optional probe is `catch`-guarded) |
| Built-in feedback | rows `command-feedback`, `message-feedback`, `ui-message-feedback` disabled | No like/dislike strip, no `/feedback` command or dialog, no acknowledgement toasts, no session-header "反馈" item |
| Official brand row (`logoRow`) | browser CSS layer | Brand mark/name hidden and the whole row collapsed — no empty gap is left in the corner. Opt-in `keepTitlebarDragStrip` preserves the 40 px Windows drag strip. |
| Empty-session hero headline | browser CSS layer | "Into the Unknown" / "探索未至之境" headline and the hero whale hidden. Matches both official builds (`Hqq-bq_headline`) and self-built DSH (`cdBAVW_headline`) by CSS-module local name inside `composerHero`. |
| Default-model guard | host half, startup | If the profile's default model no longer resolves after the account provider is removed (`NO_ADAPTER`), it is rewritten once to the first usable provider (or `fallbackModel`) through the normal config editor, so the host stays usable |
| Conversation-log backup | host half + `server/` | All stored and newly appended session events are uploaded as NDJSON batches to the self-hosted backup server; a long-lived WebSocket control channel (`/v1/device/ws`) carries status, managed config and server commands. Disabled by default. |

### Why the account service rows stay mounted

The **account RPC and platform service must stay enabled** on the desktop
profile. The Electron shell calls it before it opens its first window —
`app.asar/lib/main.js`: `openInitialWindow()` → `readWelcomeState()` → `read()`
→ `account.state()` → `POST /api/account/getState` (main.js:8964), and `read()`
has no fallback: a non-200 throws `desktop welcome: Web request failed`
(main.js:8903) into `reportFatal`, so **no window ever appears** even though the
host booted. Disabling `account-controller` / `deepseek-account` therefore breaks
the desktop app, not just the account UI.

What this build removes instead is the **renderer-side login/account surface**
(the whole `ui-settings-account` client plugin) plus the account **model
provider**. The account namespace stays alive for the shell; the login capability
is no longer reachable from the UI. Truly removing the capability needs an
Electron-shell patch (`main.js`), which a Cordis plugin cannot do. `verify.mjs`
fails the build if `account-controller` / `deepseek-account` are ever disabled
again.

Rows that **must stay mounted** and are deliberately untouched: `account-controller`,
`deepseek-account`, `credentials` (the web transport itself injects it — disabling
it kills the GUI), `settings-controller` (backs every Settings page) and
`authorization` (credential flows for enterprise providers).

## Not covered by a plugin (deployment prerequisites)

- **Desktop native welcome/sign-in window.** The Electron shell shows it when
  `!loggedIn && !hasApiKey`. It is not part of the Cordis row graph and cannot
  be removed by a plugin. Make sure at least one model API key is configured /
  discovered before first launch (see [../docs/deploy.md](../docs/deploy.md)).
- **Stored account grant + account RPC capability.** The shell requires the
  account namespace, so a stored grant remains resolvable by the host. Delete the
  account record from the credential store during provisioning if the seat must
  not retain one; for a capability-level block, patch the Electron shell.
- **Plugin management can re-enable rows.** An operator can toggle a disabled
  row back on from the Plugins page (it writes `disabled:` into the profile
  patch). Lock plugin management down separately for a locked-down seat.

## Default model: automatic guard, optional pin

Removing `llm-deepseek-account` removes the provider that the stock profile uses
as its default (`provider: deepseek-account`, `model: deepseek-flash`). Left
alone, every new session fails at its first request with
`NO_ADAPTER no adapter registered for provider "deepseek-account"` — the host
looks broken and the UI offers no repair path.

Two mechanisms cover it:

1. **Startup guard (default on, `repairDefaultModel: true`).** The host half
   classifies the configured default once providers settle. If the provider is
   gone or the model is no longer advertised, it rewrites `agent-default-model`
   to `fallbackModel` (when set) or the first provider that advertises a model,
   through the normal config editor, so the change persists. It never rewrites a
   default it cannot prove is broken (credential-gated/ambiguous catalog states
   are left alone).
2. **Install-time pin.** The installer can write the target explicitly and is
   the deterministic choice for fleet provisioning:

```powershell
node client/scripts/install-profile.mjs --profile desktop --default-model local-llm/qwen3.8-27b
```

It rewrites the profile's `agent-default-model` entry and drops the account-only
`reasoningEffort`. Set `repairDefaultModel: false` when a deployment pins its
default model out of band and must not have the plugin touch it.

## Install

```powershell
pnpm install --store-dir .pnpm-store   # workspace root, first checkout
pnpm build                             # modern build (chrome152, default)
# pnpm -C client build:legacy          # only for old-browser Web deployments
pnpm test
pnpm verify
```

Then install into the target profile (backups are automatic; the desktop profile
is installed by materializing the built package because the CLI reserves
`--profile desktop` for the Electron app):

```powershell
# guard repairs the default at first boot:
node client/scripts/install-profile.mjs --profile desktop
# or pin the target now:
node client/scripts/install-profile.mjs --profile desktop --default-model local-llm/qwen3.8-27b
```

Restart DeepSeek Harness (host composition is read at boot), then run the
verification checklist in [../docs/deploy.md](../docs/deploy.md). The full runbook —
preconditions, verification probes, rollback, upgrade procedure, known limits —
lives there.

## Configuration

The browser half reads its knobs from the plugin row in `cordis.patch.yml`.
Because the client module graph (`__DSH_BOOT__`) carries no config, the host half
publishes the resolved config through the webserver's index-injection table as
`window.__DSH_GA_CONFIG__` (a synchronous global set before any application
script runs); the browser half falls back to built-in defaults when the global is
absent. No RPC, no fetch, no flash of unstyled branding.

| Key | Default | Meaning |
|---|---|---|
| `hideLogoRow` | `true` | Hide the sidebar brand row and collapse it (no empty gap left behind) |
| `keepTitlebarDragStrip` | `false` | Keep the 40 px Windows drag strip instead of collapsing the row (only for shells that drag from it) |
| `hideHeroHeadline` | `true` | Hide the empty-session hero headline and hero whale |
| `cssMode` | `'auto'` | `auto` picks modern `:has()` rules when the browser supports them, legacy class-name rules otherwise; `modern`/`legacy` force a variant |
| `adaptiveDom` | `true` | After the static CSS, locate the rows through public anchors (`data-slot`, `data-window-drag`) and mark them, covering self-built DSH builds with different CSS-module names |
| `diagnostics` | `true` | Publish `window.__DSH_GA_DIAGNOSTICS__` (variant + which anchors matched; no conversation content) |
| `repairDefaultModel` | `true` | Rewrite an unroutable default model once so the host stays usable |
| `fallbackModel` | `''` | Preferred repair target (`provider/model`); empty = first provider with models |
| `backup` | disabled | Conversation-log backup block: `enabled`, `serverUrl`, `deviceId`, `label`, `dshVersion`, `scanIntervalMs`, `debounceMs`, `maxBatchEvents`, `maxBatchBytes`, `requestTimeoutMs`, `allowInsecureTls` (see below) |
| `extraSelectors` | `[]` | Extra CSS selectors to hide (deployment-specific leftovers) |

The hide layer has three tiers: static CSS (immediate), capability-selected
modern/legacy variant, and the adaptive DOM resolver. A self-built DSH that
renames CSS modules still gets its targets hidden through the public slot
anchors; `window.__DSH_GA_DIAGNOSTICS__` reports which anchors matched.

Disabling a whole feature row is a composition change, not a runtime knob: edit
the `disabled:` lines in `cordis.patch.yml` (and rebuild/reinstall) to restore an
official capability.

## Browser compatibility and build targets

The bundled desktop app is **Electron 44.7.0 / Chromium 152.0.7977.130**, so all
modern CSS (`:has()`, container queries, `color-mix()`) is available there. The
stock DSH UI itself already requires Chromium >= 105.

- **Default build** targets `chrome152` and is the right artifact for the
  Electron app (and any recent enterprise browser).
- **Legacy build** (`pnpm -C client build:legacy`, or
  `DSH_GA_CLIENT_TARGET=chrome96`) targets Chrome 96 for deployments whose Web
  UI is still opened by old browsers. The same bundle still upgrades to modern
  CSS at runtime when the browser supports it — only the JS syntax floor is
  fixed at build time.
- `pnpm verify` checks the syntax floor recorded in `lib/build-meta.json`;
  `pnpm -C client verify:legacy` checks the legacy build.

## Conversation-log backup (host side)

Implemented against the server in [`server/`](../server/) (the frozen contract is
[`docs/api-backup-server.md`](../docs/api-backup-server.md)). Disabled by
default; enable it in the plugin row (`cordis.patch.yml`):

```yaml
backup:
  enabled: true
  serverUrl: https://agentmanager.kxzd.sjq.sh
  # Self-signed certificate: scoped to the backup transport only (the host's
  # other HTTPS calls keep normal verification).
  allowInsecureTls: true
  # deviceId: ""        # default: sanitized hostname, hashed if not id-safe
  # label: ""           # default: hostname
  # dshVersion: ""
  scanIntervalMs: 60000
  debounceMs: 1000
  maxBatchEvents: 200
  maxBatchBytes: 1048576
```

A stable device fingerprint is computed automatically (SHA-256 of hostname,
platform, arch, Linux `/etc/machine-id`, and `DSH_HOME`) and sent as
`X-Device-Fingerprint` / `X-Device-Label` on HTTP, plus `fingerprint` in the WS
query and `hello` payload. The server uses it to separate devices that share a
hostname (the later device gets a `~<fingerprint-prefix>` suffix), while old
clients that only send `X-Device-Id` still work.

What the host half does:

1. **Initial catch-up** — `sessionPersistence.list()` finds every stored session;
   each one gets an idempotent `POST /v1/sessions/{id}/header`, whose response
   carries the server's `throughSeq` (the resume authority — no local cursor
   file). Missing events are read from the local log in chunks and uploaded.
2. **Live feed** — `ctx.on('session/event')` appends committed events to a
   per-session ordered queue; batches are framed after `debounceMs` and respect
   `maxBatchEvents` / `maxBatchBytes`.
3. **Wire format** — NDJSON: a `{"type":"batch",...}` line plus one JSON event
   per line, `application/x-ndjson`, SHA-256 checksum over the event lines,
   headers `X-Device-Id`, `X-Device-Fingerprint`, `X-Device-Label`,
   `X-Backup-Protocol: 1`,
   `X-Session-Format-Version: <header.version>`.
4. **Resilience** — 409 `SEQ_GAP` recovers the missing prefix from persistence
   and resumes at `expectedNextSeq`; 404 re-sends the header; 413 halves the
   batch; transport/5xx retries with exponential backoff; `HEADER_CONFLICT` and
   other 4xx mark that session failed until `backup.retry_failed`.
5. **Control channel** — `WS /v1/device/ws?deviceId=...&protocol=1&fingerprint=...` with
   subprotocol `dsh-backup.v1`: `hello`/`hello.ack`, `ping`/`pong` every 25 s,
   periodic `status`, `config` → `config.ack`, `command` → `command.result`,
   reconnect with backoff (the server replaces the old connection). If the host
   lacks a global `WebSocket`, HTTP backup still runs and the control channel is
   skipped with a warning.
6. **Commands** — `backup.sync` (`mode: full|incremental`), `backup.pause`,
   `backup.resume`, `backup.retry_failed`, `backup.set_limits`,
   `backup.status`, `diag.collect`. Managed config fields: `paused`,
   `debounceMs`, `intervalMs`, `maxBatchEvents`, `maxBatchBytes`.

Attachments are **not** uploaded (server `PUT /v1/blobs/*` returns 501), no
restore exists by design, the server stores plaintext and currently has no
authentication — restrict it to an internal network. `allowInsecureTls: true`
accepts the server's self-signed certificate **per backup connection only**
(native HTTP/WS transport); it never changes the host's global TLS policy, so
LLM provider calls keep normal certificate verification. Prefer installing the
internal CA and setting it back to `false` when the certificate becomes
CA-signed.

DNS matters: the DSH machine must resolve `agentmanager.kxzd.sjq.sh` to the
server (hosts entry or internal DNS). If that is not possible, use the server IP
in `serverUrl`; because `allowInsecureTls` also ignores the hostname mismatch, an
IP URL works with the domain certificate.

## Repository layout (this package)

```
cordis.patch.yml        composition lockdown + plugin row
src/index.ts            host half: publishes the config global (index injection)
src/client/index.ts     browser half: stylesheet + adaptive resolver wiring
src/client/adaptive.ts  DOM resolver (MutationObserver, data-ga-hidden marks)
src/client/adaptive-core.ts
                        pure structural lookups (unit-tested)
src/shared/config.ts    config contract, defaults, global name
src/shared/css.ts       selector registry + modern/legacy stylesheet builder
src/backup/settings.ts  backup settings (browser-safe)
src/backup/protocol.ts  framing, checksum, endpoints, header/status payloads
src/backup/http.ts      HTTP data-plane client (header + NDJSON batches)
src/backup/engine.ts    scan/live queues, resume, recovery, commands
src/backup/control.ts   WS control channel (hello, ping, config, commands)
test/client.test.mjs    integration tests against the built bundle
test/host.test.mjs      index-injection config publication test
test/adaptive-core.test.mjs
                        structural lookup tests
test/backup-protocol.test.mjs / backup-engine.test.mjs / backup-control.test.mjs
                        server-contract, engine and WS tests
scripts/build.mjs       cross-platform build wrapper (target + build-meta stamp)
scripts/verify.mjs      release-contract verifier (patch rows + target-aware syntax)
scripts/install-profile.mjs
                        profile installer + default-model migration
lib/                    built artifacts (host entry, browser bundle, build-meta.json)
```

Workspace-level docs live one level up:

```
../docs/recon/          evidence-first host recon this design is based on
../docs/deploy.md       deployment runbook, verification, rollback, limits
../docs/architecture.md mechanisms, upgrade strategy, extension points
../docs/*backup*.md     backup feature design / server P0 contract / API reference
../server/              FastAPI + PostgreSQL backup server (implemented)
```

## License

MIT
