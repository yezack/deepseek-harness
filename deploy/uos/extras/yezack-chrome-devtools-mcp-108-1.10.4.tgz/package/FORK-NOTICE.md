# FORK NOTICE

This package is an **unofficial fork** of
[chrome-devtools-mcp](https://github.com/ChromeDevTools/chrome-devtools-mcp)
(`chrome-devtools-mcp` on npm, Copyright Google LLC, Apache-2.0).

It is **not** published, endorsed or supported by Google or the Chrome DevTools
team. For the official package use `chrome-devtools-mcp`.

## What was changed

Base: upstream tag `chrome-devtools-mcp-v1.10.1` (puppeteer-core 25.11.0),
taken from the published npm tarball.

Modified files: `build/src/third_party/index.js` (one code path, plus one
helper appended to the same module), `build/src/BrowserManager.js` and
`build/src/utils/check-for-updates.js`.

### 1. Page discovery on Chrome 108-110

Upstream initialises target discovery with:

    Target.setAutoAttach { autoAttach: true, flatten: true,
                           waitForDebuggerOnStart: true,
                           filter: [{type: 'page', exclude: true}, {}] }

Chrome 111+ interprets that filter as "attach the tab targets, not the page
targets" and puppeteer then attaches each page as a child of its tab target.
Chrome 108-110 implement `Target.TargetFilter` with early allowlist semantics,
where a trailing entry without `type` does **not** re-include a type that an
earlier entry excluded. On those browsers nothing is auto-attached at all: the
puppeteer target table only contains the browser target, `browser.pages()` stays
empty, and every page tool fails (`list_pages` returned an empty array,
`navigate_page` failed with "pageId: expected number, received undefined").

This fork wraps that one call site in
`__dshCompatAutoAttachParams(connection, params)`, which probes
`Browser.getVersion` once per connection and, when the major version is below
111, removes `filter`. Those browsers then attach page targets directly, which
puppeteer handles correctly. Browsers 111 and newer are passed through unchanged.

### 2. Temporary profile by default

Upstream launches with a persistent user-data-dir at
`$HOME/.cache/chrome-devtools-mcp/chrome-profile` and creates it with `mkdir`
before launching. On a host where the home directory is a read-only mount that
fails with `EROFS`/`EPERM`, and the failure surfaces through every page tool
(`list_pages` returned that mkdir error). This fork defaults to an isolated
temporary profile instead (under the OS temp directory, e.g. `$TMPDIR` on
Linux), which is what the upstream CLI entry point already did. The default is
applied as a destructuring default rather than a yargs default, so
`--user-data-dir <path>` still wins the conflict resolution. `--no-isolated`
restores the upstream behaviour.

### 3. Update-check cache location

The update check cached the latest version in a hardcoded
`$HOME/.cache/chrome-devtools-mcp/latest.json` (20 bytes), independent of the
profile setting, so a read-only home still received a write attempt on every
start. It now picks the first writable directory out of
`$HOME/.cache/chrome-devtools-mcp` and `$TMPDIR/chrome-devtools-mcp`: normal
hosts keep the upstream location, read-only homes fall back to the OS temp
directory. `CHROME_DEVTOOLS_MCP_NO_UPDATE_CHECKS=1` skips the check entirely.

Verified against Chromium 108.0.5351.0 (snapshot r1056772) and
Chrome 154.0.8037.99.

## License

Apache-2.0, unchanged. The original LICENSE file is included. The modification
above is stated here as required by section 4(b) of the license.
